const o=""+new URL("../img/icon_question.f794a865.svg",import.meta.url).href;export{o as _};
