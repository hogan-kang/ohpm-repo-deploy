System.register([],function(e,t){"use strict";return{execute:function(){e("_",""+new URL("../img/icon_question.f794a865.svg",t.meta.url).href)}}});
